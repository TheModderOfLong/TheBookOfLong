using HarmonyLib;
using Il2Cpp;
using Il2CppInterop.Runtime;
using Il2CppSystem.Collections.Generic;
using System.Reflection;
using System;

namespace TheExtensionOfLong
{
    [SpePlotFuc("HeroDataCallFuc")]
    public static class HeroDataCallFuc
    {
        /// <summary>
        /// HeroDataCallFuc 指令：对 HeroData 实例调用指定函数
        /// 格式: HeroDataCallFuc*角色ID#函数名#函数参数(可选)
        ///   角色ID: 通过 CommonHandlers.ResolveHeroId 解析（int ID / 名称 / player 等关键字）
        ///   函数名: HeroData 的无参方法名（反射调用），或复合动作名
        ///   函数参数: 复合动作的参数，用"-"分隔
        ///
        /// 支持的无参方法(示例): GoInPrison, GoOutPrison, SetNeedRemove, DeadToAlive,
        ///   RecoverState, ResetLoyal, ResetAI, FullRecover(提示=false), RemoveLover(提示=false) 等
        ///
        /// 支持的复合动作:
        ///   ChangeForceContribution=数量-是否提示-门派ID
        ///   ChangeHeroForceLv=等级-是否提示
        ///   ChangeMoney=数量-是否提示
        ///   ChangeFame=数量-是否提示
        ///   ChangeBadFame=数量-是否提示
        ///   ChangeLoyal=数量-是否提示
        ///   ChangeFavor=数量-是否提示-最大好感-强制倍率-成功音效
        ///   ChangeHp=数量-使用恢复率-不死-刷新-提示
        ///   ChangeMana=数量-使用恢复率-刷新-提示
        ///   ChangePower=数量-提示
        ///   ChangeGovernContribution=数量-是否提示
        ///   ChangeGovernLv=等级
        ///   ChangeHornorLv=等级
        ///   SetLover=目标角色ID-是否提示
        ///   RemoveLover=是否提示
        ///   RemoveTeacher=是否提示
        ///   RemoveAllPrelover=是否提示
        ///   RemoveAllStudent=是否提示
        ///   FullRecover=是否提示
        ///   AddTag=标签ID-时间-来源-提示
        ///   RemoveTag=标签ID-是否提示
        ///   AddLog=日志内容
        ///
        /// 示例:
        ///   HeroDataCallFuc*player#GoInPrison
        ///   HeroDataCallFuc*小白#ChangeMoney=1000-true
        ///   HeroDataCallFuc*player#ChangeForceContribution=50-true--1
        ///   HeroDataCallFuc*player#ChangeFame=100-true
        ///   HeroDataCallFuc*player#ChangeHp=50-true-false-true-false
        ///   HeroDataCallFuc*小白#SetLover=player-true
        /// </summary>
        public static void TryCall(PlotController __instance, string fucName, string[] fucParams)
        {
            if (fucParams.Length < 2 || string.IsNullOrWhiteSpace(fucParams[0]) || string.IsNullOrWhiteSpace(fucParams[1]))
            {
                LoggerManager.Warning($"{fucName}: 参数不足，格式[HeroDataCallFuc*角色ID#函数名#函数参数(可选)]");
                return;
            }

            string heroIdRaw = fucParams[0];
            string funcInfo = fucParams[1];

            // 解析角色
            HeroData hero = CommonHandlers.ResolveHeroId(__instance, heroIdRaw);
            if (hero == null)
            {
                LoggerManager.Warning($"{fucName}: 未找到角色 \"{heroIdRaw}\"");
                return;
            }

            // 解析函数名和参数
            // 支持两种格式:
            //   FuncName=Arg1-Arg2    (fucParams[1] 含 =)
            //   FuncName#Arg1-Arg2    (fucParams[2] 作为参数)
            int eqIdx = funcInfo.IndexOf('=');
            string methodName;
            string methodArg;

            if (eqIdx >= 0)
            {
                methodName = funcInfo.Substring(0, eqIdx);
                methodArg = funcInfo.Substring(eqIdx + 1);
            }
            else
            {
                methodName = funcInfo;
                methodArg = fucParams.Length > 2 ? fucParams[2] : "";
            }

            // 优先匹配复合动作
            if (HeroCallFucCompositeActions.TryGetValue(methodName, out var handler))
            {
                string[] args = methodArg.Split('-');
                // 将参数中的"负"还原为"-"，以支持负数等含"-"的参数值
                for (int i = 0; i < args.Length; i++)
                {
                    args[i] = args[i].Replace("负", "-");
                }
                handler(__instance, hero, args);
                return;
            }

            // 无参复合动作（不带=号调用）
            if (HeroCallFucCompositeActions.ContainsKey(methodName))
            {
                handler(__instance, hero, new string[0]);
                return;
            }

            // 无参方法：通过反射调用
            try
            {
                var bindingFlags = System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.IgnoreCase;
                System.Reflection.MethodInfo method = hero.GetType().GetMethod(methodName, bindingFlags, null, Type.EmptyTypes, null);
                if (method != null)
                {
                    method.Invoke(hero, null);
                    LoggerManager.Debug($"{fucName}: 已调用 {hero.heroName}.{methodName}()");
                    return;
                }

                LoggerManager.Warning($"{fucName}: HeroData 未找到无参方法 \"{methodName}\"，且非已知复合动作");
            }
            catch (Exception e)
            {
                LoggerManager.Error($"{fucName}: 调用 {hero.heroName}.{methodName}() 失败: {e.Message}");
            }
        }

private static readonly System.Collections.Generic.Dictionary<string, System.Action<PlotController, HeroData, string[]>> HeroCallFucCompositeActions
            = new System.Collections.Generic.Dictionary<string, System.Action<PlotController, HeroData, string[]>>(StringComparer.OrdinalIgnoreCase)
        {
            { "ChangeForceContribution",     HeroCallFucChangeForceContribution },
            { "ChangeHeroForceLv",           HeroCallFucChangeHeroForceLv },
            { "ChangeMoney",                 HeroCallFucChangeMoney },
            { "ChangeFame",                  HeroCallFucChangeFame },
            { "ChangeBadFame",               HeroCallFucChangeBadFame },
            { "ChangeLoyal",                 HeroCallFucChangeLoyal },
            { "ChangeFavor",                 HeroCallFucChangeFavor },
            { "ChangeHp",                    HeroCallFucChangeHp },
            { "ChangeMana",                  HeroCallFucChangeMana },
            { "ChangePower",                 HeroCallFucChangePower },
            { "ChangeGovernContribution",    HeroCallFucChangeGovernContribution },
            { "ChangeGovernLv",              HeroCallFucChangeGovernLv },
            { "ChangeHornorLv",              HeroCallFucChangeHornorLv },
            { "SetLover",                    HeroCallFucSetLover },
            { "RemoveLover",                 HeroCallFucRemoveLover },
            { "RemoveTeacher",               HeroCallFucRemoveTeacher },
            { "RemoveAllPrelover",           HeroCallFucRemoveAllPrelover },
            { "RemoveAllStudent",            HeroCallFucRemoveAllStudent },
            { "FullRecover",                 HeroCallFucFullRecover },
            { "AddTag",                      HeroCallFucAddTag },
            { "RemoveTag",                   HeroCallFucRemoveTag },
            { "AddLog",                      HeroCallFucAddLog },
        };

        // ===== HeroDataCallFuc 复合动作实现 =====

        /// <summary>
        /// ChangeForceContribution=数量-是否提示-门派ID
        /// 默认: 数量=0, 提示=true, 门派ID=-1
        /// </summary>

        /// <summary>
        /// ChangeForceContribution=数量-是否提示-门派ID
        /// 默认: 数量=0, 提示=true, 门派ID=-1
        /// </summary>
        private static void HeroCallFucChangeForceContribution(PlotController pc, HeroData hero, string[] args)
        {
            float num = args.Length > 0 && float.TryParse(args[0], out float n) ? n : 0f;
            bool showInfo = args.Length < 2 || !(args[1] == "false" || args[1] == "0");
            int targetForce = args.Length > 2 && int.TryParse(args[2], out int f) ? f : -1;
            try
            {
                hero.ChangeForceContribution(num, showInfo, targetForce);
                LoggerManager.Debug($"  HeroDataCallFuc: {hero.heroName}.ChangeForceContribution({num}, {showInfo}, {targetForce})");
            }
            catch (Exception e) { LoggerManager.Error($"  HeroDataCallFuc ChangeForceContribution 失败: {e.Message}"); }
        }

        /// <summary>
        /// ChangeHeroForceLv=等级-是否提示
        /// 默认: 等级=0, 提示=true
        /// </summary>
        private static void HeroCallFucChangeHeroForceLv(PlotController pc, HeroData hero, string[] args)
        {
            int num = args.Length > 0 && int.TryParse(args[0], out int n) ? n : 0;
            bool showInfo = args.Length < 2 || !(args[1] == "false" || args[1] == "0");
            try
            {
                hero.ChangeHeroForceLv(num, showInfo);
                LoggerManager.Debug($"  HeroDataCallFuc: {hero.heroName}.ChangeHeroForceLv({num}, {showInfo})");
            }
            catch (Exception e) { LoggerManager.Error($"  HeroDataCallFuc ChangeHeroForceLv 失败: {e.Message}"); }
        }

        /// <summary>
        /// ChangeMoney=数量-是否提示
        /// 默认: 数量=0, 提示=true
        /// </summary>
        private static void HeroCallFucChangeMoney(PlotController pc, HeroData hero, string[] args)
        {
            int num = args.Length > 0 && int.TryParse(args[0], out int n) ? n : 0;
            bool showInfo = args.Length < 2 || !(args[1] == "false" || args[1] == "0");
            try
            {
                hero.ChangeMoney(num, showInfo);
                LoggerManager.Debug($"  HeroDataCallFuc: {hero.heroName}.ChangeMoney({num}, {showInfo})");
            }
            catch (Exception e) { LoggerManager.Error($"  HeroDataCallFuc ChangeMoney 失败: {e.Message}"); }
        }

        /// <summary>
        /// ChangeFame=数量-是否提示
        /// 默认: 数量=0, 提示=true
        /// </summary>
        private static void HeroCallFucChangeFame(PlotController pc, HeroData hero, string[] args)
        {
            float num = args.Length > 0 && float.TryParse(args[0], out float n) ? n : 0f;
            bool showInfo = args.Length < 2 || !(args[1] == "false" || args[1] == "0");
            try
            {
                hero.ChangeFame(num, showInfo);
                LoggerManager.Debug($"  HeroDataCallFuc: {hero.heroName}.ChangeFame({num}, {showInfo})");
            }
            catch (Exception e) { LoggerManager.Error($"  HeroDataCallFuc ChangeFame 失败: {e.Message}"); }
        }

        /// <summary>
        /// ChangeBadFame=数量-是否提示
        /// 默认: 数量=0, 提示=true
        /// </summary>
        private static void HeroCallFucChangeBadFame(PlotController pc, HeroData hero, string[] args)
        {
            float num = args.Length > 0 && float.TryParse(args[0], out float n) ? n : 0f;
            bool showInfo = args.Length < 2 || !(args[1] == "false" || args[1] == "0");
            try
            {
                hero.ChangeBadFame(num, showInfo);
                LoggerManager.Debug($"  HeroDataCallFuc: {hero.heroName}.ChangeBadFame({num}, {showInfo})");
            }
            catch (Exception e) { LoggerManager.Error($"  HeroDataCallFuc ChangeBadFame 失败: {e.Message}"); }
        }

        /// <summary>
        /// ChangeLoyal=数量-是否提示
        /// 默认: 数量=0, 提示=false
        /// </summary>
        private static void HeroCallFucChangeLoyal(PlotController pc, HeroData hero, string[] args)
        {
            float num = args.Length > 0 && float.TryParse(args[0], out float n) ? n : 0f;
            bool showInfo = args.Length > 1 && (args[1] == "true" || args[1] == "1");
            try
            {
                hero.ChangeLoyal(num, showInfo);
                LoggerManager.Debug($"  HeroDataCallFuc: {hero.heroName}.ChangeLoyal({num}, {showInfo})");
            }
            catch (Exception e) { LoggerManager.Error($"  HeroDataCallFuc ChangeLoyal 失败: {e.Message}"); }
        }

        /// <summary>
        /// ChangeFavor=数量-是否提示-最大好感-强制倍率-成功音效
        /// 默认: 数量=0, 提示=true, 最大好感=100, 强制倍率=0, 成功音效=false
        /// </summary>
        private static void HeroCallFucChangeFavor(PlotController pc, HeroData hero, string[] args)
        {
            float num = args.Length > 0 && float.TryParse(args[0], out float n) ? n : 0f;
            bool showPopInfo = args.Length < 2 || !(args[1] == "false" || args[1] == "0");
            float maxFavor = args.Length > 2 && float.TryParse(args[2], out float mf) ? mf : 100f;
            float forceRate = args.Length > 3 && float.TryParse(args[3], out float fr) ? fr : 0f;
            bool successSound = args.Length > 4 && (args[4] == "true" || args[4] == "1");
            try
            {
                hero.ChangeFavor(num, showPopInfo, maxFavor, forceRate, successSound);
                LoggerManager.Debug($"  HeroDataCallFuc: {hero.heroName}.ChangeFavor({num}, {showPopInfo}, {maxFavor}, {forceRate}, {successSound})");
            }
            catch (Exception e) { LoggerManager.Error($"  HeroDataCallFuc ChangeFavor 失败: {e.Message}"); }
        }

        /// <summary>
        /// ChangeHp=数量-使用恢复率-不死-刷新-提示
        /// 默认: 数量=0, 使用恢复率=true, 不死=false, 刷新=true, 提示=false
        /// </summary>
        private static void HeroCallFucChangeHp(PlotController pc, HeroData hero, string[] args)
        {
            float num = args.Length > 0 && float.TryParse(args[0], out float n) ? n : 0f;
            bool useRecoverRate = args.Length < 2 || !(args[1] == "false" || args[1] == "0");
            bool noDead = args.Length > 2 && (args[2] == "true" || args[2] == "1");
            bool needRefresh = args.Length < 4 || !(args[3] == "false" || args[3] == "0");
            bool showInfo = args.Length > 4 && (args[4] == "true" || args[4] == "1");
            try
            {
                hero.ChangeHp(num, useRecoverRate, noDead, needRefresh, showInfo);
                LoggerManager.Debug($"  HeroDataCallFuc: {hero.heroName}.ChangeHp({num}, {useRecoverRate}, {noDead}, {needRefresh}, {showInfo})");
            }
            catch (Exception e) { LoggerManager.Error($"  HeroDataCallFuc ChangeHp 失败: {e.Message}"); }
        }

        /// <summary>
        /// ChangeMana=数量-使用恢复率-刷新-提示
        /// 默认: 数量=0, 使用恢复率=true, 刷新=true, 提示=false
        /// </summary>
        private static void HeroCallFucChangeMana(PlotController pc, HeroData hero, string[] args)
        {
            float num = args.Length > 0 && float.TryParse(args[0], out float n) ? n : 0f;
            bool useRecoverRate = args.Length < 2 || !(args[1] == "false" || args[1] == "0");
            bool needRefresh = args.Length < 3 || !(args[2] == "false" || args[2] == "0");
            bool showInfo = args.Length > 3 && (args[3] == "true" || args[3] == "1");
            try
            {
                hero.ChangeMana(num, useRecoverRate, needRefresh, showInfo);
                LoggerManager.Debug($"  HeroDataCallFuc: {hero.heroName}.ChangeMana({num}, {useRecoverRate}, {needRefresh}, {showInfo})");
            }
            catch (Exception e) { LoggerManager.Error($"  HeroDataCallFuc ChangeMana 失败: {e.Message}"); }
        }

        /// <summary>
        /// ChangePower=数量-提示
        /// 默认: 数量=0, 提示=false
        /// </summary>
        private static void HeroCallFucChangePower(PlotController pc, HeroData hero, string[] args)
        {
            float num = args.Length > 0 && float.TryParse(args[0], out float n) ? n : 0f;
            bool showInfo = args.Length > 1 && (args[1] == "true" || args[1] == "1");
            try
            {
                hero.ChangePower(num, showInfo);
                LoggerManager.Debug($"  HeroDataCallFuc: {hero.heroName}.ChangePower({num}, {showInfo})");
            }
            catch (Exception e) { LoggerManager.Error($"  HeroDataCallFuc ChangePower 失败: {e.Message}"); }
        }

        /// <summary>
        /// ChangeGovernContribution=数量-是否提示
        /// 默认: 数量=0, 提示=true
        /// </summary>
        private static void HeroCallFucChangeGovernContribution(PlotController pc, HeroData hero, string[] args)
        {
            float num = args.Length > 0 && float.TryParse(args[0], out float n) ? n : 0f;
            bool showInfo = args.Length < 2 || !(args[1] == "false" || args[1] == "0");
            try
            {
                hero.ChangeGovernContribution(num, showInfo);
                LoggerManager.Debug($"  HeroDataCallFuc: {hero.heroName}.ChangeGovernContribution({num}, {showInfo})");
            }
            catch (Exception e) { LoggerManager.Error($"  HeroDataCallFuc ChangeGovernContribution 失败: {e.Message}"); }
        }

        /// <summary>
        /// ChangeGovernLv=等级
        /// 默认: 等级=0
        /// </summary>
        private static void HeroCallFucChangeGovernLv(PlotController pc, HeroData hero, string[] args)
        {
            int num = args.Length > 0 && int.TryParse(args[0], out int n) ? n : 0;
            try
            {
                hero.ChangeGovernLv(num);
                LoggerManager.Debug($"  HeroDataCallFuc: {hero.heroName}.ChangeGovernLv({num})");
            }
            catch (Exception e) { LoggerManager.Error($"  HeroDataCallFuc ChangeGovernLv 失败: {e.Message}"); }
        }

        /// <summary>
        /// ChangeHornorLv=等级
        /// 默认: 等级=0
        /// </summary>
        private static void HeroCallFucChangeHornorLv(PlotController pc, HeroData hero, string[] args)
        {
            int num = args.Length > 0 && int.TryParse(args[0], out int n) ? n : 0;
            try
            {
                hero.ChangeHornorLv(num);
                LoggerManager.Debug($"  HeroDataCallFuc: {hero.heroName}.ChangeHornorLv({num})");
            }
            catch (Exception e) { LoggerManager.Error($"  HeroDataCallFuc ChangeHornorLv 失败: {e.Message}"); }
        }

        /// <summary>
        /// SetLover=目标角色ID-是否提示
        /// 默认: 目标角色ID=空, 提示=false
        /// </summary>
        private static void HeroCallFucSetLover(PlotController pc, HeroData hero, string[] args)
        {
            if (args.Length < 1 || string.IsNullOrWhiteSpace(args[0]))
            {
                LoggerManager.Warning("  HeroDataCallFuc SetLover: 参数不足，格式[SetLover=目标角色ID-是否提示]");
                return;
            }
            HeroData target = CommonHandlers.ResolveHeroId(pc, args[0]);
            if (target == null)
            {
                LoggerManager.Warning($"  HeroDataCallFuc SetLover: 未找到目标角色 \"{args[0]}\"");
                return;
            }
            bool showInfo = args.Length > 1 && (args[1] == "true" || args[1] == "1");
            try
            {
                hero.SetLover(target.heroID, showInfo);
                LoggerManager.Debug($"  HeroDataCallFuc: {hero.heroName}.SetLover({target.heroID}, {showInfo})");
            }
            catch (Exception e) { LoggerManager.Error($"  HeroDataCallFuc SetLover 失败: {e.Message}"); }
        }

        /// <summary>
        /// RemoveLover=是否提示
        /// 默认: 提示=false
        /// </summary>
        private static void HeroCallFucRemoveLover(PlotController pc, HeroData hero, string[] args)
        {
            bool showInfo = args.Length > 0 && (args[0] == "true" || args[0] == "1");
            try
            {
                hero.RemoveLover(showInfo);
                LoggerManager.Debug($"  HeroDataCallFuc: {hero.heroName}.RemoveLover({showInfo})");
            }
            catch (Exception e) { LoggerManager.Error($"  HeroDataCallFuc RemoveLover 失败: {e.Message}"); }
        }

        /// <summary>
        /// RemoveTeacher=是否提示
        /// 默认: 提示=false
        /// </summary>
        private static void HeroCallFucRemoveTeacher(PlotController pc, HeroData hero, string[] args)
        {
            bool showInfo = args.Length > 0 && (args[0] == "true" || args[0] == "1");
            try
            {
                hero.RemoveTeacher(showInfo);
                LoggerManager.Debug($"  HeroDataCallFuc: {hero.heroName}.RemoveTeacher({showInfo})");
            }
            catch (Exception e) { LoggerManager.Error($"  HeroDataCallFuc RemoveTeacher 失败: {e.Message}"); }
        }

        /// <summary>
        /// RemoveAllPrelover=是否提示
        /// 默认: 提示=false
        /// </summary>
        private static void HeroCallFucRemoveAllPrelover(PlotController pc, HeroData hero, string[] args)
        {
            bool showInfo = args.Length > 0 && (args[0] == "true" || args[0] == "1");
            try
            {
                hero.RemoveAllPrelover(showInfo);
                LoggerManager.Debug($"  HeroDataCallFuc: {hero.heroName}.RemoveAllPrelover({showInfo})");
            }
            catch (Exception e) { LoggerManager.Error($"  HeroDataCallFuc RemoveAllPrelover 失败: {e.Message}"); }
        }

        /// <summary>
        /// RemoveAllStudent=是否提示
        /// 默认: 提示=false
        /// </summary>
        private static void HeroCallFucRemoveAllStudent(PlotController pc, HeroData hero, string[] args)
        {
            bool showInfo = args.Length > 0 && (args[0] == "true" || args[0] == "1");
            try
            {
                hero.RemoveAllStudent(showInfo);
                LoggerManager.Debug($"  HeroDataCallFuc: {hero.heroName}.RemoveAllStudent({showInfo})");
            }
            catch (Exception e) { LoggerManager.Error($"  HeroDataCallFuc RemoveAllStudent 失败: {e.Message}"); }
        }

        /// <summary>
        /// FullRecover=是否提示
        /// 默认: 提示=false
        /// </summary>
        private static void HeroCallFucFullRecover(PlotController pc, HeroData hero, string[] args)
        {
            bool showInfo = args.Length > 0 && (args[0] == "true" || args[0] == "1");
            try
            {
                hero.FullRecover(showInfo);
                LoggerManager.Debug($"  HeroDataCallFuc: {hero.heroName}.FullRecover({showInfo})");
            }
            catch (Exception e) { LoggerManager.Error($"  HeroDataCallFuc FullRecover 失败: {e.Message}"); }
        }

        /// <summary>
        /// AddTag=标签ID-时间-来源-提示
        /// 默认: 标签ID=0, 时间=-1, 来源=null, 提示=false
        /// </summary>
        private static void HeroCallFucAddTag(PlotController pc, HeroData hero, string[] args)
        {
            if (args.Length < 1 || !int.TryParse(args[0], out int tagId))
            {
                LoggerManager.Warning("  HeroDataCallFuc AddTag: 参数不足或无效，格式[AddTag=标签ID-时间-来源-提示]");
                return;
            }
            float time = args.Length > 1 && float.TryParse(args[1], out float t) ? t : -1f;
            string source = args.Length > 2 ? args[2] : null;
            if (source == "null") source = null;
            bool showInfo = args.Length > 3 && (args[3] == "true" || args[3] == "1");
            try
            {
                hero.AddTag(tagId, time, source, showInfo);
                LoggerManager.Debug($"  HeroDataCallFuc: {hero.heroName}.AddTag({tagId}, {time}, {source}, {showInfo})");
            }
            catch (Exception e) { LoggerManager.Error($"  HeroDataCallFuc AddTag 失败: {e.Message}"); }
        }

        /// <summary>
        /// RemoveTag=标签ID-是否提示
        /// 默认: 标签ID=0, 提示=false
        /// </summary>
        private static void HeroCallFucRemoveTag(PlotController pc, HeroData hero, string[] args)
        {
            if (args.Length < 1 || !int.TryParse(args[0], out int tagId))
            {
                LoggerManager.Warning("  HeroDataCallFuc RemoveTag: 参数不足或无效，格式[RemoveTag=标签ID-是否提示]");
                return;
            }
            bool showInfo = args.Length > 1 && (args[1] == "true" || args[1] == "1");
            try
            {
                hero.RemoveTag(tagId, showInfo);
                LoggerManager.Debug($"  HeroDataCallFuc: {hero.heroName}.RemoveTag({tagId}, {showInfo})");
            }
            catch (Exception e) { LoggerManager.Error($"  HeroDataCallFuc RemoveTag 失败: {e.Message}"); }
        }

        /// <summary>
        /// AddLog=日志内容
        /// </summary>
        private static void HeroCallFucAddLog(PlotController pc, HeroData hero, string[] args)
        {
            if (args.Length < 1 || string.IsNullOrWhiteSpace(args[0]))
            {
                LoggerManager.Warning("  HeroDataCallFuc AddLog: 参数不足，格式[AddLog=日志内容]");
                return;
            }
            try
            {
                hero.AddLog(args[0]);
                LoggerManager.Debug($"  HeroDataCallFuc: {hero.heroName}.AddLog(\"{args[0]}\")");
            }
            catch (Exception e) { LoggerManager.Error($"  HeroDataCallFuc AddLog 失败: {e.Message}"); }
        }
    }
}
