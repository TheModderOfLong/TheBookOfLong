using Il2Cpp;

namespace TheExtensionOfLong
{
    /// <summary>
    /// 设置存档内持久化定时器，到期后执行指定回调函数。
    /// 具体参数解析、保存和触发逻辑统一委托给 TimerManager。
    /// 格式: SetTimer*定时器ID#定时器类型#时间参数#回调函数名#函数参数#自定义参数#是否强制更新#是否立即触发
    /// </summary>
    [SpePlotFuc("SetTimer")]
    public static class SetTimer
    {
        public static void TryCall(PlotController plotController, string fucName, string[] fucParams)
        {
            TimerManager.HandleSetTimer(plotController, fucName, fucParams);
        }
    }
}
