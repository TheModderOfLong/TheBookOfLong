using System;
using HarmonyLib;
using Il2Cpp;
using Il2CppSystem.Collections.Generic;

namespace TheExtensionOfLong
{
    /// <summary>
    /// 对 PlotController.ChangeNextPlot() 的全面替换 Patch
    ///
    /// 原方法流程：
    ///   1. oldSinglePlot = nowSinglePlot
    ///   2. 获取 firstPlot = nowPlot.plotDatas[0]
    ///   3. 若 clickCallFuc 非空：
    ///      a. "ScreenBlack" → ScreenBlack() 并返回
    ///      b. 用 '|' 分割多个回调，每个用 ';' 分割方法名和参数
    ///      c. 通过 SendMessage 执行，每次检测剧情是否切换（oldSinglePlot != nowSinglePlot）
    ///      d. 若发生切换，noAutoJump=true → ScreenBlack() 并返回
    ///   4. 若 noAutoJump=false → GoNextPlot()
    ///
    /// 注意：已有的 ChangeNextPlotQueryResolvePatch 仅做查询指令解析（Prefix修改、Postfix恢复），
    ///       本 Patch 完全接管原方法，两者同时存在时 ChangeNextPlotQueryResolvePatch 的 Prefix
    ///       会先执行（解析查询指令），然后本 Patch 的 Prefix 执行（return false 阻止原方法），
    ///       原 ChangeNextPlot 不会执行。
    ///       如需整合，可将查询解析逻辑合并到本 Patch 中。
    /// </summary>
    [HarmonyPatch(typeof(PlotController), "ChangeNextPlot")]
    public static class ChangeNextPlotPatch
    {
        [HarmonyPrefix]
        public static bool ChangeNextPlotPrefix(PlotController __instance)
        {
            try
            {
                // 1. 保存当前 SinglePlotData
                __instance.oldSinglePlot = __instance.nowSinglePlot;

                // 2. 获取 firstPlot
                var nowPlot = __instance.nowPlot;
                if (nowPlot == null) return false;
                var plotDatas = nowPlot.plotDatas;
                if (plotDatas == null || plotDatas.Count == 0) return false;
                SinglePlotData firstPlot = plotDatas[0];
                if (firstPlot == null) return false;

                // 3. 读取 noAutoJump 标志
                bool noAutoJump = firstPlot.noAutoJump;

                // 4. 处理 clickCallFuc
                string clickCallFuc = firstPlot.clickCallFuc;
                if (!string.IsNullOrEmpty(clickCallFuc))
                {
                    // 4a. 特殊值 "ScreenBlack"
                    //if (clickCallFuc == "ScreenBlack")
                    //{
                    //    __instance.ScreenBlack();
                    //    return false;
                    //}

                    // 4b. 用 '|' 分割多个回调（(()) 保护内部 | 不被拆分）
                    string[] callBacks = CommonHandlers.SplitRespectingBraces(clickCallFuc, '|');
                    for (int i = 0; i < callBacks.Length; i++)
                    {
                        string singleCallBack = callBacks[i];
                        // 解析所有指令语法（查询 + 算术 + 未来扩展，统一由 ConditionQueryHandlers 处理）ChangeNextPlotPatch
                        string resolved = ConditionQueryHandlers.ResolveAllCommands(__instance, singleCallBack);
                        if (resolved != singleCallBack)
                        {
                            LoggerManager.Debug($"ChangeNextPlot.SendMessage解析: \"{singleCallBack}\" → \"{resolved}\"");
                            singleCallBack = resolved;
                        }
                        // 用 ';' 分割方法名和参数（(()) 保护内部 ; 不被拆分）
                        string[] parts = CommonHandlers.SplitRespectingBraces(singleCallBack, ';');

                        if (parts.Length < 2)
                        {
                            // 无参数
                            __instance.gameObject.SendMessage(parts[0]);
                        }
                        else
                        {
                            // 有参数，剥离 (()) 分隔符保护符
                            string methodArg = CommonHandlers.StripParens(parts[1]);
                            __instance.gameObject.SendMessage(parts[0], methodArg);
                        }

                        // 检测 SendMessage 是否导致剧情切换
                        if (__instance.oldSinglePlot != __instance.nowSinglePlot)
                        {
                            noAutoJump = true;
                        }
                    }

                    // 4c. SendMessage 导致剧情切换 → 黑屏过渡
                    if (noAutoJump)
                    {
                        // __instance.ScreenBlack();
                        // return false;
                    }
                }

                // 5. noAutoJump == false 时自动推进
                if (!noAutoJump)
                {
                    __instance.GoNextPlot();
                }

                return false; // 阻止原方法执行
            }
            catch (Exception ex)
            {
                LoggerManager.Error($"ChangeNextPlotPatch 异常: {ex}");
                return true; // 异常时回退到原方法
            }
        }
    }
}
