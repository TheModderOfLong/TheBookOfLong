using System;
using HarmonyLib;
using Il2Cpp;

namespace CommandExtensionOfLong
{
    /// <summary>
    /// 对 PlotController.ChangeNextPlot() 的 HarmonyPrefix + HarmonyPostfix 补丁
    /// 在 SendMessage 执行前解析 clickCallFuc 中的查询指令和算术表达式，
    /// 执行后恢复原始值（双重保险，防止数据持久化）
    ///
    /// 解析由 ConditionQueryHandlers.ResolveAllCommands 统一处理，
    /// 支持 [$查询$]、[&算术&] 及嵌套 [&[$A$]+[$B$]&]
    /// </summary>
    [HarmonyPatch(typeof(PlotController), "ChangeNextPlot")]
    public class ChangeNextPlotQueryResolvePatch
    {
        // 保存原始 clickCallFuc，用于 Postfix 恢复
        [ThreadStatic]
        private static string _originalClickCallFuc;

        // 保存被修改的 firstPlot 引用，用于 Postfix 精准恢复
        // （SendMessage 可能触发 ChangePlot 导致 nowPlot 变化，不能通过 nowPlot 查找）
        [ThreadStatic]
        private static SinglePlotData _modifiedPlot;

        [HarmonyPrefix]
        public static void ChangeNextPlotPrefix(PlotController __instance)
        {
            _modifiedPlot = null;
            _originalClickCallFuc = null;

            // 1. 获取 firstPlot
            var nowPlot = __instance.nowPlot;
            if (nowPlot == null) return;
            var plotDatas = nowPlot.plotDatas;
            if (plotDatas == null || plotDatas.Count == 0) return;
            SinglePlotData firstPlot = plotDatas[0];
            if (firstPlot == null) return;

            string clickCallFuc = firstPlot.clickCallFuc;
            if (string.IsNullOrEmpty(clickCallFuc)) return;

            // 2. 快速跳过：不含任何可解析指令语法则无需处理
            if (!ConditionQueryHandlers.ContainsParseableSyntax(clickCallFuc)) return;

            // 3. 保存原值 + 引用
            _originalClickCallFuc = clickCallFuc;
            _modifiedPlot = firstPlot;

            // 4. 解析所有指令语法（查询 + 算术 + 未来扩展，统一由 ConditionQueryHandlers 处理）
            string resolved = ConditionQueryHandlers.ResolveAllCommands(__instance, clickCallFuc);

            // 5. 写回
            if (resolved != clickCallFuc)
            {
                firstPlot.clickCallFuc = resolved;
                LoggerManager.Debug($"ChangeNextPlot查询解析: \"{Truncate(clickCallFuc, 1000)}\" → \"{Truncate(resolved, 1000)}\"");
            }
            else
            {
                // 无变化，不需要恢复
                _modifiedPlot = null;
                _originalClickCallFuc = null;
            }
        }

        [HarmonyPostfix]
        public static void ChangeNextPlotPostfix(PlotController __instance)
        {
            if (_modifiedPlot == null || _originalClickCallFuc == null) return;

            // 通过引用直接恢复，不依赖 nowPlot（可能已被 ChangePlot 替换）
            _modifiedPlot.clickCallFuc = _originalClickCallFuc;
            LoggerManager.Debug("ChangeNextPlot查询解析: 已恢复原始clickCallFuc");

            _modifiedPlot = null;
            _originalClickCallFuc = null;
        }

        private static string Truncate(string text, int maxLength)
        {
            if (text == null) return "null";
            if (text.Length <= maxLength) return text;
            return text.Substring(0, maxLength) + $"...(总长{text.Length})";
        }
    }
}
