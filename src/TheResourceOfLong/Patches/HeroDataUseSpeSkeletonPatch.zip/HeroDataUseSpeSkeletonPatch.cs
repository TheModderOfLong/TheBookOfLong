using System;
using HarmonyLib;
using Il2Cpp;

namespace TheResourceOfLong
{
    [HarmonyPatch(typeof(HeroData), "UseSpeSkeleton")]
    internal static class HeroDataUseSpeSkeletonPatch
    {
        [HarmonyPostfix]
        public static void Postfix(HeroData __instance, ref bool __result)
        {
            if (!__result) return;

            try
            {
                if (SpeHeroSkeletonPolicy.HasCompatibleSpeSkeletonBranchResource(__instance)) return;

                __result = false;
                LoggerManager.Debug("Disabled vanilla SpeSkeleton branch because compatible SkeletonDataAsset resource is missing. heroID=" +
                                    (__instance == null ? 0 : __instance.heroID) +
                                    ", heroName=" + (__instance == null ? string.Empty : __instance.heroName) +
                                    ", path=" + SpeHeroSkeletonPolicy.GetVanillaSpeHeroSkeletonPath(__instance));
            }
            catch (Exception ex)
            {
                LoggerManager.Debug("Failed to check vanilla SpeSkeleton asset existence: " + ex.Message);
            }
        }
    }
}
